# RevitAIRenderer Installer for Revit 2023
# Right-click this file and select "Run with PowerShell"

Write-Host "RevitAIRenderer Installer for Revit 2023" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan
Write-Host

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePath = Join-Path $scriptPath "Files"
$revitVersion = "2023"

Write-Host "Checking required files..." -ForegroundColor Yellow
if (-not (Test-Path (Join-Path $sourcePath "RevitAIRenderer.dll"))) {
    Write-Host "ERROR: RevitAIRenderer.dll not found in the Files folder." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

if (-not (Test-Path (Join-Path $sourcePath "Newtonsoft.Json.dll"))) {
    Write-Host "ERROR: Newtonsoft.Json.dll not found in the Files folder." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

if (-not (Test-Path (Join-Path $sourcePath "RevitAIRenderer.addin"))) {
    Write-Host "ERROR: RevitAIRenderer.addin not found in the Files folder." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

# Try ProgramData first (shared by all users)
$programDataPath = [Environment]::GetFolderPath("CommonApplicationData")
Write-Host "Checking write access to ProgramData: $programDataPath" -ForegroundColor Yellow

try {
    $testFile = Join-Path $programDataPath "test_write.tmp"
    [io.file]::WriteAllText($testFile, "Test")
    Remove-Item $testFile -Force -ErrorAction SilentlyContinue
    $hasWriteAccessToProgramData = $true
}
catch {
    $hasWriteAccessToProgramData = $false
}

# Determine installation location
if ($hasWriteAccessToProgramData) {
    Write-Host "Installing for all users (ProgramData)..." -ForegroundColor Green
    $installRoot = $programDataPath
}
else {
    Write-Host "Cannot write to ProgramData, installing for current user only..." -ForegroundColor Yellow
    $installRoot = [Environment]::GetFolderPath("ApplicationData")
}

# Create add-in folder if it doesn't exist
$addinsFolder = Join-Path $installRoot "Autodesk\Revit\Addins\$revitVersion"
if (-not (Test-Path $addinsFolder)) {
    Write-Host "Creating Revit addins folder: $addinsFolder" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $addinsFolder -Force | Out-Null
}

# Create plugin folder
$pluginFolder = Join-Path $addinsFolder "RevitAIRenderer"
if (-not (Test-Path $pluginFolder)) {
    Write-Host "Creating plugin folder: $pluginFolder" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $pluginFolder -Force | Out-Null
}

# Copy DLL and dependencies
Write-Host "Copying RevitAIRenderer.dll..." -ForegroundColor Yellow
Copy-Item -Path (Join-Path $sourcePath "RevitAIRenderer.dll") -Destination $pluginFolder -Force

Write-Host "Copying Newtonsoft.Json.dll..." -ForegroundColor Yellow
Copy-Item -Path (Join-Path $sourcePath "Newtonsoft.Json.dll") -Destination $pluginFolder -Force

# Create resources folder and copy resources
$resourcesFolder = Join-Path $pluginFolder "Resources"
if (-not (Test-Path $resourcesFolder)) {
    Write-Host "Creating resources folder: $resourcesFolder" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $resourcesFolder -Force | Out-Null
}

if (Test-Path (Join-Path $sourcePath "Resources\render_icon.png")) {
    Write-Host "Copying icon resources..." -ForegroundColor Yellow
    Copy-Item -Path (Join-Path $sourcePath "Resources\render_icon.png") -Destination $resourcesFolder -Force
}
else {
    Write-Host "WARNING: Icon file not found, ribbon button will use default appearance." -ForegroundColor Yellow
}

# Copy and modify .addin file
Write-Host "Configuring .addin manifest file..." -ForegroundColor Yellow
$addinSource = Join-Path $sourcePath "RevitAIRenderer.addin"
$addinDest = Join-Path $addinsFolder "RevitAIRenderer.addin"

$addinContent = Get-Content $addinSource -Raw
$addinContent = $addinContent -replace "AIrender.dll", (Join-Path $pluginFolder "RevitAIRenderer.dll")
$addinContent = $addinContent -replace "AIrender.AppStartup", "RevitAIRenderer.AppStartup"
$addinContent | Set-Content $addinDest -Force

# Create data directories
Write-Host "Setting up data directories..." -ForegroundColor Yellow
$localAppData = [Environment]::GetFolderPath("LocalApplicationData")
$dataFolders = @(
    (Join-Path $localAppData "RevitAIRenderer"),
    (Join-Path $localAppData "RevitAIRenderer\Temp"),
    (Join-Path $localAppData "RevitAIRenderer\Results")
)

foreach ($folder in $dataFolders) {
    if (-not (Test-Path $folder)) {
        Write-Host "Creating data folder: $folder" -ForegroundColor Yellow
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
    }
}

# Create default settings file
$settingsPath = Join-Path $localAppData "RevitAIRenderer\settings.json"
if (-not (Test-Path $settingsPath)) {
    Write-Host "Creating default settings file..." -ForegroundColor Yellow
    $defaultSettings = @{
        ApiKey = ""
        DefaultPrompt = "photorealistic rendering, high quality, architectural visualization"
        Strength = 0.85
        Steps = 28
        GuidanceScale = 3.5
        OfflineMode = $false
        OutputFormat = "jpeg"
        ControlLoraStrength = 1.0
        StylePreset = ""
        ControlStrength = 0.7
        UseSystemProxy = $true
        ProxyAddress = ""
        ProxyPort = 8080
        ProxyRequiresAuthentication = $false
        ProxyUsername = ""
        ProxyPassword = ""
        ApiTimeoutSeconds = 300
        VerboseLogging = $false
        MaxLogFileSizeMB = 10
    }

    $settingsJson = ConvertTo-Json $defaultSettings -Depth 5
    Set-Content -Path $settingsPath -Value $settingsJson -Force
}

Write-Host
Write-Host "===================================" -ForegroundColor Green
Write-Host "Installation completed successfully!" -ForegroundColor Green
Write-Host "===================================" -ForegroundColor Green
Write-Host
Write-Host "The RevitAIRenderer add-in has been installed for Revit 2023." -ForegroundColor Cyan
Write-Host
Write-Host "Installation location: $pluginFolder" -ForegroundColor White
Write-Host "Settings file location: $settingsPath" -ForegroundColor White
Write-Host
Write-Host "Important Notes:" -ForegroundColor Yellow
Write-Host "1. Please restart Revit 2023 to use the add-in" -ForegroundColor White
Write-Host "2. You'll need a Stability AI API key to use the renderer" -ForegroundColor White
Write-Host

Read-Host "Press Enter to exit"